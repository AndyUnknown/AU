#include "Headers.h"
#include <wx/wx.h>


void Nod::clicked(wxCommandEvent& event)
{

	if (map_data[this->ID] ==1)
	{
		nods[this->ID] = new Unlocked_Nod(this->GetParent(), this->ID, this->GetPosition(), wxSize(20, 20), wxBORDER_NONE);
		change_nearby(this->ID);
		this->Destroy();
	}
	else if (map_data[this->ID] == 2)
	{
		monsters[this->ID] =new Monster_1(this->GetParent(),this->ID, this->GetPosition(), wxSize(60,60), wxBORDER_NONE);
		nods[this->ID] = monsters[this->ID];

		change_nearby_by_monster(this->ID,false);
		this->Destroy();
	}
	else if (map_data[this->ID] == 3)
	{
		if (rand() % 2 == 1)
		{
			nods[this->ID] = new Gear_repair(this->GetParent(), this->ID, this->GetPosition(), wxSize(20, 20), wxBORDER_NONE);
		}
		else
		{
			nods[this->ID] = new Gear_weak(this->GetParent(), this->ID, this->GetPosition(), wxSize(20, 20), wxBORDER_NONE);
		}
		
		change_nearby(this->ID);
		this->Destroy();
	}
	else if (map_data[this->ID] == 1024)
	{
		nods[this->ID] = new Core(this->GetParent(), this->ID, this->GetPosition(), wxSize(60, 60), wxBORDER_NONE);
		change_nearby(this->ID);
		this->Destroy();
	}

}


Nod::Nod(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name):
	wxButton(parent, id, wxEmptyString, pos, size, style, validator, name)
{
	ID = int(id);
	this->SetBitmap(bitmap_nod_normal);
	this->SetBitmapCurrent(bitmap_nod_hover);
	this->SetBitmapDisabled(bitmap_nod_disabled);
	Bind(wxEVT_BUTTON, &Nod::clicked, this, int(id));
};




