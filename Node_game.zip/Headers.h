#ifndef headers_h
#define headers_h

#include <wx/wxprec.h>
#include <wx/wx.h>

void change_nearby(int id);
void change_nearby_by_monster(int ID,bool flag);

class Nod;
class Monster;
class Monster_1;
class Player;

extern Player *p1;
extern int map_data[400];
extern Nod* nods[400];
extern Monster* monsters[400];

extern wxBitmap bitmap_nod_normal;
extern wxBitmap bitmap_nod_hover;
extern wxBitmap bitmap_nod_disabled;
extern wxBitmap bitmap_unlocked_nod_disabled;
extern wxBitmap bitmap_unlocked_nod_normal;
extern wxBitmap bitmap_monster;
extern wxBitmap bitmap_core;
extern wxBitmap bitmap_blood__100;
extern wxBitmap bitmap_blood_100;
extern wxBitmap bitmap_blood_90;
extern wxBitmap bitmap_blood_80;
extern wxBitmap bitmap_blood_70;
extern wxBitmap bitmap_blood_60;
extern wxBitmap bitmap_blood_50;
extern wxBitmap bitmap_blood_40;
extern wxBitmap bitmap_blood_30;
extern wxBitmap bitmap_blood_20;
extern wxBitmap bitmap_blood_10;
extern wxBitmap bitmap_blood_0;

extern wxBitmap bitmap_n_1;
extern wxBitmap bitmap_n_2;
extern wxBitmap bitmap_n_3;
extern wxBitmap bitmap_n_4;
extern wxBitmap bitmap_n_5;
extern wxBitmap bitmap_n_6;
extern wxBitmap bitmap_n_7;
extern wxBitmap bitmap_n_8;
extern wxBitmap bitmap_n_9;
extern wxBitmap bitmap_n_0;

extern wxBitmap bitmap_gear_repair;
extern wxBitmap bitmap_gear_repair_disabled;
extern wxBitmap bitmap_gear_weak;
extern wxBitmap bitmap_gear_weak_disabled;
extern wxBitmap bitmap_health;
extern wxBitmap bitmap_atk;

extern const int colnum;
extern const int linenum;

extern int Frame_x;
extern int Frame_y;

Nod* Nod_Up(Nod* nod);
Nod* Nod_Down(Nod* nod);
Nod* Nod_Left(Nod* nod);
Nod* Nod_Right(Nod* nod);
Nod* Nod_UpLeft(Nod* nod);
Nod* Nod_UpRight(Nod* nod);
Nod* Nod_DownLeft(Nod* nod);
Nod* Nod_DownRight(Nod* nod);


void set_pics();
void gen_data();
void gen_map(wxWindow* parent,wxWindowID id,const wxSize& size,long style);

class MyApp : public wxApp
{
public:
	virtual bool OnInit();
};


class MyFrame : public wxFrame
{
public:
	MyFrame();

};



class Nod :public wxButton
{
public:
	int ID ;
	int is_under_control=0;

	Nod(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);
	
	
	void clicked(wxCommandEvent& event);
};



class Unlocked_Nod :public Nod
{
public:
	Unlocked_Nod(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);
};



class Monster :public Nod
{
public:
	int hitpoint=0;
	int max_hitpoint=0;
	int atk = 0;
	wxStaticBitmap* Bloodbars[3] = { NULL,NULL,NULL};
	wxStaticBitmap* Atkbars[3] = { NULL,NULL,NULL };
	Monster(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);

	void set_bloodbars();
	void set_atkbars();

	void clicked(wxCommandEvent& event);
	void kill();
};

class Core :public Monster//Ѫ��40������15
{
public:
	Core(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);

	
	void clicked(wxCommandEvent& event);
	void kill();
};


class Monster_1 :public Monster//Ѫ��80������40
{
public:
	Monster_1(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);
};




class Player
{
public:
	int max_player_hitpoint = 600;
	int player_atk = 20;
	int player_hitpoint = max_player_hitpoint;

	wxWindow* Parent;
	wxStaticBitmap* Bloodbars[3];
//	wxStaticBitmap* Atkbars[3];

	Player(wxWindow* parent);
	void set_player_bloodbars();
	int has_weak = 0;
	~Player() 
	{
		for (int i = 0;i < 3;++i)
		{
			if (Bloodbars[i] != NULL)
				delete Bloodbars[i];
		}
	}

};

class Gear :public Nod
{
public:
	Gear(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);
};


class Gear_repair:public Gear
{
public:
	Gear_repair(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);

	void clicked(wxCommandEvent& event);

};

class Gear_weak :public Gear
{
public:
	Gear_weak(wxWindow* parent,
		wxWindowID id,
		const wxPoint& pos = wxDefaultPosition,
		const wxSize& size = wxDefaultSize,
		long style = 0,
		const wxValidator& validator = wxDefaultValidator,
		const wxString& name = wxButtonNameStr);

	void clicked(wxCommandEvent& event);
};

#endif