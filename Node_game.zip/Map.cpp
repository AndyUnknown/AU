#include "cstdlib"
#include <wx/wx.h>
#include "Headers.h"
const int colnum = 18;
const int linenum = 9;

int map_data[400];
Nod* nods[400];
Monster* monsters[400];


void gen_data()
{
	//0:no nod
	//1:normal nod
	//2:monster_1
	//3:gear_repair
	//1024:core
	for (int i = 0;i < 400;++i)
	{
		map_data[i] = rand()%4;
		monsters[i] = NULL;
	}
}

void gen_map(wxWindow* parent, wxWindowID id, const wxSize& size, long style)
{
	gen_data();
	int somenum = rand() % (linenum * colnum-1);
	map_data[somenum] = 1024;
	int l1 = Frame_x / 20;
	int l2 = Frame_y / 12;
	for (int i = 0;i < linenum;++i)
	{
		for (int j = 0;j < colnum;++j)
		{
			if (map_data[i * colnum + j] != 0)
			{
				nods[i * colnum + j] = new Nod(parent, i * colnum + j, wxPoint(l1 + l1 * j, l2 - 30 + l2 * i), size, style);
				nods[i * colnum + j]->Disable();
			}

		}
	}

	for (int i = 0;i < colnum;++i)
	{
		if (map_data[i] != 0)
		{
			nods[i]->Enable();
			break;
		}
	}

}

void change_nearby(int ID)
{
	int line = ID / colnum;
	int col = ID % colnum;
	Nod* nod_up = Nod_Up(nods[ID]);
	Nod* nod_down = Nod_Down(nods[ID]);
	Nod* nod_left = Nod_Left(nods[ID]);
	Nod* nod_right = Nod_Right(nods[ID]);
	Nod* nod_upleft = Nod_UpLeft(nods[ID]);
	Nod* nod_upright = Nod_UpRight(nods[ID]);
	Nod* nod_downleft = Nod_DownLeft(nods[ID]);
	Nod* nod_downright = Nod_DownRight(nods[ID]);
	
	
		if (nod_up != NULL && (!nod_up->is_under_control))
			nod_up->Enable();
		if (nod_down != NULL && (!nod_down->is_under_control))
			nod_down->Enable();
		if (nod_left != NULL && (!nod_left->is_under_control))
			nod_left->Enable();
		if (nod_right != NULL && (!nod_right->is_under_control))
			nod_right->Enable();

		if (nod_upleft != NULL && (!nod_upleft->is_under_control))
			nod_upleft->Enable();
		if (nod_upright != NULL && (!nod_upright->is_under_control))
			nod_upright->Enable();
		if (nod_downleft != NULL && (!nod_downleft->is_under_control))
			nod_downleft->Enable();
		if (nod_downright != NULL && (!nod_downright->is_under_control))
			nod_downright->Enable();
	
}

void change_nearby_by_monster(int ID, bool flag)
{
	//flag=0:infect 
	//flag=1:cure
	int line = ID / colnum;
	int col = ID % colnum;
	Nod* nod_up = Nod_Up(nods[ID]);
	Nod* nod_down = Nod_Down(nods[ID]);
	Nod* nod_left = Nod_Left(nods[ID]);
	Nod* nod_right = Nod_Right(nods[ID]);
	Nod* nod_upleft = Nod_UpLeft(nods[ID]);
	Nod* nod_upright = Nod_UpRight(nods[ID]);
	Nod* nod_downleft = Nod_DownLeft(nods[ID]);
	Nod* nod_downright = Nod_DownRight(nods[ID]);
	if (!flag)
	{
		if (nod_up != NULL)
		{
			nod_up->Disable();
			nod_up->is_under_control++;
		}
		if (nod_down != NULL)
		{
			nod_down->Disable();
			nod_down->is_under_control++;
		}
		if (nod_left != NULL)
		{
			nod_left->Disable();
			nod_left->is_under_control++;
		}
		if (nod_right != NULL)
		{
			nod_right->Disable();
			nod_right->is_under_control++;
		}
		if (nod_upleft != NULL)
		{
			nod_upleft->Disable();
			nod_upleft->is_under_control++;
		}
		if (nod_upright != NULL)
		{
			nod_upright->Disable();
			nod_upright->is_under_control++;
		}
		if (nod_downleft != NULL)
		{
			nod_downleft->Disable();
			nod_downleft->is_under_control++;
		}
		if (nod_downright != NULL)
		{
			nod_downright->Disable();
			nod_downright->is_under_control++;
		}
	}
	else
	{
		if (nod_up != NULL)
		{
			if(nod_up->is_under_control>0)
				nod_up->is_under_control--;
		}
		if (nod_down != NULL)
		{
			if (nod_down->is_under_control > 0)
				nod_down->is_under_control--;
		}
		if (nod_left != NULL)
		{
			if (nod_left->is_under_control > 0)
				nod_left->is_under_control--;
		}
		if (nod_right != NULL)
		{
			if (nod_right->is_under_control > 0)
				nod_right->is_under_control--;
		}
		if (nod_upleft != NULL)
		{
			if (nod_upleft->is_under_control > 0)
				nod_upleft->is_under_control--;
		}
		if (nod_upright != NULL)
		{
			if (nod_upright->is_under_control > 0)
				nod_upright->is_under_control--;
		}
		if (nod_downleft != NULL)
		{
			if (nod_downleft->is_under_control > 0)
				nod_downleft->is_under_control--;
		}
		if (nod_downright != NULL)
		{
			if (nod_downright->is_under_control > 0)
				nod_downright->is_under_control--;
		}

	}
	
}



