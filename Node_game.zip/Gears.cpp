#include "Headers.h"

Gear::Gear(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name):
	Nod(parent, id, pos, size, style, validator, name)
{
	SetSize(wxSize(30, 30));
	wxPoint temp = pos;
	temp.x = pos.x - 5;
	temp.y = pos.y - 5;
	SetPosition(temp);

}

void Gear_repair::clicked(wxCommandEvent& event)
{
	p1->player_hitpoint += 30;
	p1->set_player_bloodbars();
	wxPoint temp = GetPosition();
	temp.x += 5;
	temp.y += 5;
	map_data[ID] = 1;
	nods[ID] = new Unlocked_Nod(GetParent(), ID, temp, wxSize(20, 20), wxBORDER_NONE);
	Destroy();
	
}


Gear_repair::Gear_repair(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Gear(parent, id, pos, size, style, validator, name)
{
	SetBitmap(bitmap_gear_repair);
	SetBitmapCurrent(bitmap_gear_repair);
	SetBitmapDisabled(bitmap_gear_repair_disabled);
	Bind(wxEVT_BUTTON, &Gear_repair::clicked, this, int(id));
}

Gear_weak::Gear_weak(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Gear(parent, id, pos, size, style, validator, name)
{
	SetBitmap(bitmap_gear_weak);
	SetBitmapCurrent(bitmap_gear_weak);
	SetBitmapDisabled(bitmap_gear_weak_disabled);
	Bind(wxEVT_BUTTON, &Gear_weak::clicked, this, int(id));
}

void Gear_weak::clicked(wxCommandEvent& event)
{
	p1->has_weak += 3;
	wxPoint temp = GetPosition();
	temp.x += 5;
	temp.y += 5;
	map_data[ID] = 1;
	nods[ID] = new Unlocked_Nod(GetParent(), ID, temp, wxSize(20, 20), wxBORDER_NONE);
	Destroy();
}
