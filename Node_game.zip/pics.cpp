#include "Headers.h"
#include <wx/wx.h>

 wxImage nod_normal;
 wxImage nod_hover;
 wxImage nod_disabled;
 wxImage unlocked_nod_normal;
 wxImage unlocked_nod_disabled;
 wxImage monster;
 wxImage core;

 wxBitmap bitmap_nod_normal;
 wxBitmap bitmap_nod_hover;
 wxBitmap bitmap_nod_disabled;
 wxBitmap bitmap_unlocked_nod_disabled;
 wxBitmap bitmap_unlocked_nod_normal;
 wxBitmap bitmap_monster;
 wxBitmap bitmap_core;

 wxImage blood__100;
 wxImage blood_100;
 wxImage blood_90;
 wxImage blood_80;
 wxImage blood_70;
 wxImage blood_60;
 wxImage blood_50;
 wxImage blood_40;
 wxImage blood_30;
 wxImage blood_20;
 wxImage blood_10;
 wxImage blood_0;
 wxBitmap bitmap_blood__100;
 wxBitmap bitmap_blood_100;
 wxBitmap bitmap_blood_90;
 wxBitmap bitmap_blood_80;
 wxBitmap bitmap_blood_70;
 wxBitmap bitmap_blood_60;
 wxBitmap bitmap_blood_50;
 wxBitmap bitmap_blood_40;
 wxBitmap bitmap_blood_30;
 wxBitmap bitmap_blood_20;
 wxBitmap bitmap_blood_10;
 wxBitmap bitmap_blood_0;



 wxImage n_1;
 wxImage n_2;
 wxImage n_3;
 wxImage n_4;
 wxImage n_5;
 wxImage n_6;
 wxImage n_7;
 wxImage n_8;
 wxImage n_9;
 wxImage n_0;

 wxImage health;
 wxImage atk;
 wxBitmap bitmap_health;
 wxBitmap bitmap_atk;


 wxBitmap bitmap_n_1;
 wxBitmap bitmap_n_2;
 wxBitmap bitmap_n_3;
 wxBitmap bitmap_n_4;
 wxBitmap bitmap_n_5;
 wxBitmap bitmap_n_6;
 wxBitmap bitmap_n_7;
 wxBitmap bitmap_n_8;
 wxBitmap bitmap_n_9;
 wxBitmap bitmap_n_0;


 wxImage gear_repair;
 wxImage gear_repair_disabled;
 wxImage gear_weak;
 wxImage gear_weak_disabled;

 wxBitmap bitmap_gear_repair;
 wxBitmap bitmap_gear_repair_disabled;
 wxBitmap bitmap_gear_weak;
 wxBitmap bitmap_gear_weak_disabled;

void set_pics()
{

	nod_normal.LoadFile("icons/nods/nod_normal.bmp", wxBITMAP_TYPE_BMP);
	nod_hover.LoadFile("icons/nods/nod_hover.bmp", wxBITMAP_TYPE_BMP);
	nod_disabled.LoadFile("icons/nods/nod_disabled.bmp", wxBITMAP_TYPE_BMP);
	unlocked_nod_normal.LoadFile("icons/nods/unlocked_nod_normal.bmp", wxBITMAP_TYPE_BMP);
	unlocked_nod_disabled.LoadFile("icons/nods/unlocked_nod_disabled.bmp", wxBITMAP_TYPE_BMP);
	monster.LoadFile("icons/monsters/monster1.bmp", wxBITMAP_TYPE_BMP);
	core.LoadFile("icons/monsters/core.bmp", wxBITMAP_TYPE_BMP);

//	blood__100.LoadFile("icons/blood/-100.bmp", wxBITMAP_TYPE_BMP);
	blood_100.LoadFile("icons/blood/100.bmp", wxBITMAP_TYPE_BMP);
	blood_90.LoadFile("icons/blood/90.bmp", wxBITMAP_TYPE_BMP);
	blood_80.LoadFile("icons/blood/80.bmp", wxBITMAP_TYPE_BMP);
	blood_70.LoadFile("icons/blood/70.bmp", wxBITMAP_TYPE_BMP);
	blood_60.LoadFile("icons/blood/60.bmp", wxBITMAP_TYPE_BMP);
	blood_50.LoadFile("icons/blood/50.bmp", wxBITMAP_TYPE_BMP);
	blood_40.LoadFile("icons/blood/40.bmp", wxBITMAP_TYPE_BMP);
	blood_30.LoadFile("icons/blood/30.bmp", wxBITMAP_TYPE_BMP);
	blood_20.LoadFile("icons/blood/20.bmp", wxBITMAP_TYPE_BMP);
	blood_10.LoadFile("icons/blood/10.bmp", wxBITMAP_TYPE_BMP);
	blood_0.LoadFile("icons/blood/0.bmp", wxBITMAP_TYPE_BMP);

	
	n_1.LoadFile("icons/nums/1.bmp", wxBITMAP_TYPE_BMP);
	n_2.LoadFile("icons/nums/2.bmp", wxBITMAP_TYPE_BMP);
	n_3.LoadFile("icons/nums/3.bmp", wxBITMAP_TYPE_BMP);
	n_4.LoadFile("icons/nums/4.bmp", wxBITMAP_TYPE_BMP);
	n_5.LoadFile("icons/nums/5.bmp", wxBITMAP_TYPE_BMP);
	n_6.LoadFile("icons/nums/6.bmp", wxBITMAP_TYPE_BMP);
	n_7.LoadFile("icons/nums/7.bmp", wxBITMAP_TYPE_BMP);
	n_8.LoadFile("icons/nums/8.bmp", wxBITMAP_TYPE_BMP);
	n_9.LoadFile("icons/nums/9.bmp", wxBITMAP_TYPE_BMP);
	n_0.LoadFile("icons/nums/0.bmp", wxBITMAP_TYPE_BMP);

	bitmap_n_1 = n_1;
	bitmap_n_2 = n_2;
	bitmap_n_3 = n_3;
	bitmap_n_4 = n_4;
	bitmap_n_5 = n_5;
	bitmap_n_6 = n_6;
	bitmap_n_7 = n_7;
	bitmap_n_8 = n_8;
	bitmap_n_9 = n_9;
	bitmap_n_0 = n_0;


	health.LoadFile("icons/nums/health.bmp", wxBITMAP_TYPE_BMP);
	atk.LoadFile("icons/nums/atk.bmp", wxBITMAP_TYPE_BMP);
	bitmap_health = health;
	bitmap_atk = atk;
	bitmap_core = core;


	bitmap_nod_normal = nod_normal;
	bitmap_nod_hover = nod_hover;
	bitmap_nod_disabled = nod_disabled;
	bitmap_unlocked_nod_disabled = unlocked_nod_disabled;
	bitmap_unlocked_nod_normal = unlocked_nod_normal;
	bitmap_monster = monster;

//	bitmap_blood__100 = blood__100;
	bitmap_blood_100= blood_100;
	bitmap_blood_90 = blood_90;
	bitmap_blood_80 = blood_80;
	bitmap_blood_70 = blood_70;
	bitmap_blood_60 = blood_60;
	bitmap_blood_50 = blood_50;
	bitmap_blood_40 = blood_40;
	bitmap_blood_30 = blood_30;
	bitmap_blood_20 = blood_20;
	bitmap_blood_10 = blood_10;
	bitmap_blood_0 = blood_0;

	gear_repair.LoadFile("icons/gears/gear_repair.bmp", wxBITMAP_TYPE_BMP);
	gear_repair_disabled.LoadFile("icons/gears/gear_repair_disabled.bmp", wxBITMAP_TYPE_BMP);
	gear_weak.LoadFile("icons/gears/gear_weak.bmp", wxBITMAP_TYPE_BMP);
	gear_weak_disabled.LoadFile("icons/gears/gear_weak_disabled.bmp", wxBITMAP_TYPE_BMP);
	bitmap_gear_repair= gear_repair;
	bitmap_gear_repair_disabled= gear_repair_disabled;
	bitmap_gear_weak = gear_weak;
	bitmap_gear_weak_disabled = gear_weak_disabled;
}
