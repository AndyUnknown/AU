#include "Headers.h"
#include <wx/wx.h>
extern int map_data[400];
extern Nod* nods[400];



Unlocked_Nod::Unlocked_Nod(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Nod(parent, id, pos, size, style, validator, name)
{

	this->SetBitmap(bitmap_unlocked_nod_normal);
	this->SetBitmapCurrent(bitmap_unlocked_nod_normal);
	this->SetBitmapDisabled(bitmap_unlocked_nod_disabled);

}

