#include "Headers.h"
#include <wx/wx.h>


Monster::Monster(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Nod(parent, id, pos, size, style, validator, name)
{
	SetSize(wxSize(60, 60));
	wxPoint temp = pos;
	temp.x = pos.x-20;
	temp.y = pos.y-20;
	SetPosition(temp);	
}



Monster_1::Monster_1(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Monster(parent, id, pos, size, style, validator, name)
{
	max_hitpoint = 80;
	atk = 40;
	hitpoint = max_hitpoint;

	set_bloodbars();
	set_atkbars();

	SetBitmap(bitmap_monster);
	SetBitmapCurrent(bitmap_monster);
	Bind(wxEVT_BUTTON, &Monster_1::clicked, this, int(id));
}

Core::Core(wxWindow* parent,
	wxWindowID id,
	const wxPoint& pos,
	const wxSize& size,
	long style,
	const wxValidator& validator,
	const wxString& name) :
	Monster(parent, id, pos, size, style, validator, name)
{
	max_hitpoint = 40;
	atk = 15;
	hitpoint = max_hitpoint;

	set_bloodbars();
	set_atkbars();

	SetBitmap(bitmap_core);
	SetBitmapCurrent(bitmap_core);
	Bind(wxEVT_BUTTON, &Core::clicked, this, int(id));
}



void Monster::clicked(wxCommandEvent& event)
{
	if (p1->has_weak > 0)
	{
		atk /= 2;
		p1->has_weak--;
		if (p1->has_weak < 0)
			p1->has_weak = 0;
		set_atkbars();
	}
	hitpoint -= p1->player_atk;
	
	p1->player_hitpoint -= atk;
	p1->set_player_bloodbars();
	if (hitpoint <= 0)
	{
		kill();
	}
	else
		set_bloodbars();
}

void Monster::kill()
{
	wxPoint temp = GetPosition();
	temp.x += 20;
	temp.y += 20;


	change_nearby_by_monster(ID, true);
	change_nearby(ID);
	nods[ID] = new Unlocked_Nod(GetParent(), ID, temp, wxSize(20, 20), wxBORDER_NONE);
	map_data[ID] = 1;

	for (int i = 0;i < 3;++i)
	{
		Bloodbars[i]->Destroy();
		Atkbars[i]->Destroy();
	}

	monsters[ID] = NULL;
	Destroy();
}

void Core::clicked(wxCommandEvent& event)
{
	int hp = hitpoint-p1->player_atk;
	__super::clicked(event);
	if (hp <= 0)
	{
		kill();
	}
}

void Core::kill()
{
	
	Nod* nodstemp[400];
	for (int i = 0;i < linenum * colnum;++i)
	{
		if (map_data[i]!=0)
		{
			wxPoint p1 = nods[i]->GetPosition();

			if (monsters[i]!=NULL)
			{		
				p1.x += 20;
				p1.y += 20;
				nodstemp[i] = new Unlocked_Nod(nods[i]->GetParent(), nods[i]->ID, p1, wxSize(20, 20), wxBORDER_NONE);
				monsters[i]->kill();	
			}
			else
			{
				nods[i]->SetBitmap(bitmap_unlocked_nod_normal);
				nods[i]->SetBitmapDisabled(bitmap_unlocked_nod_normal);
				nods[i]->SetBitmapCurrent(bitmap_unlocked_nod_normal);
				if (nods[i]->GetSize() != wxSize(20, 20))
				{
					p1.x += 5;
					p1.y += 5;
					nods[i]->SetSize(wxSize(20, 20));
					nods[i]->SetPosition(p1);
				}
			}				
		}
	}
}



void Monster::set_atkbars( )
{
	int a3 = atk % 10;
	int a2 = atk / 10;
	wxPoint Atkbar_pos = GetPosition();

	Atkbar_pos.x += 43;
	Atkbar_pos.y += 65;
	if (Atkbars[0] != NULL)
		for (int i = 0;i < 3;++i)
		{
			Atkbars[i]->Destroy();
		}


	switch (a3)
	{
	case 0:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_0, Atkbar_pos);
		break;
	case 1:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_1, Atkbar_pos);
		break;
	case 2:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_2, Atkbar_pos);
		break;
	case 3:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_3, Atkbar_pos);
		break;
	case 4:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_4, Atkbar_pos);
		break;
	case 5:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_5, Atkbar_pos);
		break;
	case 6:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_6, Atkbar_pos);
		break;
	case 7:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_7, Atkbar_pos);
		break;
	case 8:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_8, Atkbar_pos);
		break;
	case 9:
		Atkbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_9, Atkbar_pos);
		break;
	}
	Atkbar_pos.x -= 12;
	switch (a2)
	{
	case 0:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_0, Atkbar_pos);
		break;
	case 1:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_1, Atkbar_pos);
		break;
	case 2:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_2, Atkbar_pos);
		break;
	case 3:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_3, Atkbar_pos);
		break;
	case 4:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_4, Atkbar_pos);
		break;
	case 5:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_5, Atkbar_pos);
		break;
	case 6:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_6, Atkbar_pos);
		break;
	case 7:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_7, Atkbar_pos);
		break;
	case 8:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_8, Atkbar_pos);
		break;
	case 9:
		Atkbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_9, Atkbar_pos);
		break;
	}

	Atkbar_pos.x -= 20;
	Atkbars[0] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_atk, Atkbar_pos);

}
void Monster::set_bloodbars( )
{

	if(Bloodbars[0]!=NULL)
		for (int i = 0;i < 3;++i)
		{
			Bloodbars[i]->Destroy();
		}


	int a3 = hitpoint % 10;
	int a2 = hitpoint / 10;
	wxPoint Bloodbar_pos = GetPosition();
	wxPoint Atkbar_pos = GetPosition();

	Bloodbar_pos.x += 43;
	Bloodbar_pos.y -= 15;

	switch (a3) 
	{
	case 0:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_0, Bloodbar_pos);
		break;
	case 1:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_1, Bloodbar_pos);
		break;
	case 2:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_2, Bloodbar_pos);
		break;
	case 3:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_3, Bloodbar_pos);
		break;
	case 4: 
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_4, Bloodbar_pos);
		break;
	case 5:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_5, Bloodbar_pos);
		break;
	case 6:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_6, Bloodbar_pos);
		break;
	case 7:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_7, Bloodbar_pos);
		break;
	case 8:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_8, Bloodbar_pos);
		break;
	case 9:
		Bloodbars[2] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_9, Bloodbar_pos);
		break;
	}
	Bloodbar_pos.x -= 12;
	switch (a2)
	{
	case 0:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_0, Bloodbar_pos);
		break;
	case 1:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_1, Bloodbar_pos);
		break;
	case 2:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_2, Bloodbar_pos);
		break;
	case 3:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_3, Bloodbar_pos);
		break;
	case 4:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_4, Bloodbar_pos);
		break;
	case 5:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_5, Bloodbar_pos);
		break;
	case 6:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_6, Bloodbar_pos);
		break;
	case 7:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_7, Bloodbar_pos);
		break;
	case 8:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_8, Bloodbar_pos);
		break;
	case 9:
		Bloodbars[1] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_n_9, Bloodbar_pos);
		break;
	}
	
	Bloodbar_pos.x -= 20;
	Bloodbars[0] = new wxStaticBitmap(GetParent(), GetId() * 100, bitmap_health, Bloodbar_pos);
		

}