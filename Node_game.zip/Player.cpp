#include "Headers.h"

Player::Player(wxWindow* parent)
{
	Parent = parent;
	wxPoint p1;
	p1.x = Frame_x / 2 - 300;
	p1.y = Frame_y - 175;
	
	Bloodbars[0] = new wxStaticBitmap(parent, -1, bitmap_blood_100, p1);
	p1.y += 60;
	Bloodbars[1] = new wxStaticBitmap(parent, -1, bitmap_blood__100, p1);

}

void Player::set_player_bloodbars()
{
	if (Bloodbars[0] != NULL)
		Bloodbars[0]->Destroy();
	if (player_hitpoint > max_player_hitpoint)
		player_hitpoint = max_player_hitpoint;
	wxPoint p1;
	p1.x = Frame_x / 2 - 300;
	p1.y = Frame_y - 175;

	
	int proportion = player_hitpoint * 100 / max_player_hitpoint;
	if (proportion >= 95)
	{
		Bloodbars[0]= new wxStaticBitmap(Parent, -1, bitmap_blood_100, p1);
		return;
	}
	if (proportion >= 85)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_90, p1);
		return;
	}
	if (proportion >= 75)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_80, p1);
		return;
	}
	if (proportion >= 65)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_70, p1);
		return;
	}
	if (proportion >= 55)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_60, p1);
		return;
	}
	if (proportion >= 45)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_50, p1);
		return;
	}
	if (proportion >= 35)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_40, p1);
		return;
	}
	if (proportion >= 25)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_30, p1);
		return;
	}
	if (proportion >= 15)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_20, p1);
		return;
	}
	if (proportion >= 5)
	{
		Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_10, p1);
		return;
	}

	Bloodbars[0] = new wxStaticBitmap(Parent, -1, bitmap_blood_0, p1);

}