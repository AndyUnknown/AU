// wxWidgets "Hello World" Program

// For compilers that support precompilation, includes "wx/wx.h".


#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif
#include "Headers.h"

int Frame_x = 1800;
int Frame_y = 1000;

Player *p1;

enum
{
	ID_Hello = -2,
	ID_frame = -1
};

wxIMPLEMENT_APP(MyApp);



bool MyApp::OnInit()
{
	
	MyFrame* frame = new MyFrame();

	frame->Show(true);

	return true;
}


MyFrame::MyFrame()
	: wxFrame(NULL, ID_frame, "Hello World", wxPoint(100,40), wxSize(1800,1000))
{
	
	set_pics();
	
	wxPanel* panel = new wxPanel(this, wxID_ANY);

	panel->SetBackgroundColour(wxColour(0, 0, 0));

	gen_map( panel, ID_frame, wxSize(20, 20), wxBORDER_NONE);

	p1 = new Player(panel);
	
}