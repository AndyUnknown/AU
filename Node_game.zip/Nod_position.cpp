#include "Headers.h"

Nod* Nod_Up(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (line > 0 && map_data[ID - colnum] != 0 )
		return nods[ID - colnum];
	return NULL;
}

Nod* Nod_Down(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (line < linenum - 1 && map_data[ID + colnum] != 0)
		return nods[ID + colnum];
	return NULL;
}
Nod* Nod_Left(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (col > 0 && map_data[ID - 1] != 0)
		return nods[ID - 1];
	return NULL;
}
Nod* Nod_Right(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (col < colnum - 1 && map_data[ID + 1] != 0)
		return nods[ID + 1];
	return NULL;
}
Nod* Nod_UpLeft(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (line > 0 && col > 0 && map_data[ID - colnum - 1] != 0)
		return nods[ID - colnum - 1];
	return NULL;
}
Nod* Nod_UpRight(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (line > 0 && col < colnum - 1 && map_data[ID - colnum + 1] != 0)
		return nods[ID - colnum + 1];
	return NULL;
}
Nod* Nod_DownLeft(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	if (line < linenum - 1 && col > 0 && map_data[ID + colnum - 1] != 0)
		return nods[ID + colnum - 1];
	return NULL;
}
Nod* Nod_DownRight(Nod* nod)
{
	int ID = nod->ID;
	int line = ID / colnum;
	int col = ID % colnum;
	
	if (line < linenum - 1 && col < colnum - 1 && map_data[ID + colnum + 1] != 0)
		return nods[ID + colnum + 1];
	return NULL;
}