#include<stdio.h>
#include"headers7.h"
extern car *carp;
extern int timeall;
extern int carall;
extern int roadstatus(roadwesn *m);
extern double maxgone(roadwesn *m);

void gogogo(int a)
{
	int m,n,b;
	m=carp[a].frontcar;
	n=carp[a].gone;
	if(carp[a].frontcar==-1)
	{
		carp[a].speedcar=carp[a].location->speed;
	}
	else
	{
		b=carp[m].gone-carp[a].gone;
		if(b<20)
		carp[a].speedcar=0;
		if(b>40)
		carp[a].speedcar=carp[a].location->speed;
		if(b>=20&&b<=40)
		carp[a].speedcar=0.5*carp[a].location->speed;
	}
	if(n<maxgone(carp[a].location))
	carp[a].gone=carp[a].gone+carp[a].speedcar;
	n=carp[a].gone;
	if(n>=maxgone(carp[a].location))
	carp[a].gone=maxgone(carp[a].location);
	//printf("car %d moved %f at %d\n",a,carp[a].gone,timeall);

}