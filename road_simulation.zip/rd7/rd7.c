#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"

int time1,timeall,tr,carall;
extern int dir( roadwesn *m,int o);
extern void light(int n);
extern double maxgone(roadwesn *m);
extern void origin();
extern void gogogo(int a);
car *carp;
int cut=0;
int carnum;

main()
{
	//srand(time(NULL));
	carall=140;
	int a,b=0,c,n,p,q,s,t;
	double m;
    roadwesn *yonghed1we,*yonghed2we,*gonghexns,*guangyanns,*pengjiang1we,*pengjiang2we,*pingxinggns,*yonghed1ew,*yonghed2ew,*gonghexsn,*guangyansn,*pengjiang1ew,*pengjiang2ew,*pingxinggsn;
    yonghed1we=malloc(sizeof(roadwesn));
    yonghed2we=malloc(sizeof(roadwesn));
    gonghexns=malloc(sizeof(roadwesn));
    guangyanns=malloc(sizeof(roadwesn));
    pengjiang1we=malloc(sizeof(roadwesn));
    pengjiang2we=malloc(sizeof(roadwesn));
    pingxinggns=malloc(sizeof(roadwesn));
    yonghed1ew=malloc(sizeof(roadwesn));
    yonghed2ew=malloc(sizeof(roadwesn));
    gonghexsn=malloc(sizeof(roadwesn));
    guangyansn=malloc(sizeof(roadwesn));
    pengjiang1ew=malloc(sizeof(roadwesn));
    pengjiang2ew=malloc(sizeof(roadwesn));
    pingxinggsn=malloc(sizeof(roadwesn));
    


    
    yonghed1we->leftout=NULL;
    yonghed1we->rightout=guangyanns;
    yonghed1we->stout=yonghed2we;
    yonghed1we->carsum=10;
    yonghed1we->laneleftout=0;
	yonghed1we->lanerightout=1;
	yonghed1we->lanestout=1;
	yonghed1we->special=1;
	yonghed1we->direction=1;
	yonghed1we->speed=50/3.6;
	yonghed1we->length=300;
	yonghed1we->cargo=0;
	yonghed1we->lastcar0=-1;
	yonghed1we->lastcar1=-1;
	yonghed1we->lastcar2=-1;
	yonghed1we->golane=-1;
	
    yonghed2we->leftout=NULL;
    yonghed2we->rightout=pingxinggns;
    yonghed2we->stout=NULL;
    yonghed2we->carsum=10;
    yonghed2we->laneleftout=0;
	yonghed2we->lanerightout=1;
	yonghed2we->lanestout=0;
	yonghed2we->special=0;
	yonghed2we->direction=1;
	yonghed2we->speed=50/3.6;
    yonghed2we->length=300;
    yonghed2we->cargo=0;
    yonghed2we->lastcar2=-1;
    yonghed2we->lastcar1=-1;
    yonghed2we->lastcar0=-1;
    yonghed2we->golane=-1;

    gonghexsn->leftout=NULL;
    gonghexsn->rightout=yonghed1we;
    gonghexsn->stout=NULL;
    gonghexsn->carsum=10;
    gonghexsn->laneleftout=0;
	gonghexsn->lanerightout=1;
	gonghexsn->lanestout=0;
	gonghexsn->special=0;
	gonghexsn->direction=3;
	gonghexsn->speed=50/3.6;
    gonghexsn->length=300;
    gonghexsn->cargo=0;
    gonghexsn->lastcar0=-1;
    gonghexsn->lastcar1=-1;
    gonghexsn->lastcar2=-1;
    gonghexsn->golane=-1;
    
    guangyansn->leftout=yonghed1ew;
    guangyansn->rightout=yonghed2we;
    guangyansn->stout=NULL;
    guangyansn->carsum=10;
    guangyansn->laneleftout=1;
	guangyansn->lanerightout=1;
	guangyansn->lanestout=0;
	guangyansn->special=0;
	guangyansn->direction=3;
	guangyansn->speed=50/3.6;
    guangyansn->length=400;
    guangyansn->cargo=0;
    guangyansn->lastcar0=-1;
    guangyansn->lastcar1=-1;
    guangyansn->lastcar2=-1;
    guangyansn->golane=-1;
                                                                                 
    pengjiang1we->leftout=guangyansn;
    pengjiang1we->rightout=NULL;
    pengjiang1we->stout=pengjiang2we;
    pengjiang1we->carsum=10;
    pengjiang1we->laneleftout=1;
	pengjiang1we->lanerightout=0;
	pengjiang1we->lanestout=1;
	pengjiang1we->special=0;
	pengjiang1we->direction=1;
	pengjiang1we->speed=50/3.6;
    pengjiang1we->length=200;
    pengjiang1we->cargo=0;
    pengjiang1we->lastcar0=-1;
    pengjiang1we->lastcar1=-1;
    pengjiang1we->lastcar2=-1;
    pengjiang1we->golane=-1;

    pengjiang2we->leftout=pingxinggsn;
    pengjiang2we->rightout=NULL;
    pengjiang2we->stout=NULL;
    pengjiang2we->carsum=10;
    pengjiang2we->laneleftout=1;
	pengjiang2we->lanerightout=0;
	pengjiang2we->lanestout=0;
	pengjiang2we->special=0;
	pengjiang2we->direction=1;
	pengjiang2we->speed=50/3.6;
    pengjiang2we->length=200;
    pengjiang2we->cargo=0;
    pengjiang2we->lastcar0=-1;
    pengjiang2we->lastcar1=-1;
    pengjiang2we->lastcar2=-1;
    pengjiang2we->golane=-1;

    pingxinggsn->leftout=yonghed2ew;
    pingxinggsn->rightout=NULL;
    pingxinggsn->stout=NULL;
    pingxinggsn->carsum=10;
    pingxinggsn->laneleftout=1;
	pingxinggsn->lanerightout=0;
	pingxinggsn->lanestout=0;
	pingxinggsn->special=0;
	pingxinggsn->direction=3;
	pingxinggsn->speed=50/3.6;
	pingxinggsn->length=450;
	pingxinggsn->cargo=0;
	pingxinggsn->lastcar0=-1;
	pingxinggsn->lastcar1=-1;
	pingxinggsn->lastcar2=-1;
	pingxinggsn->golane=-1;







    yonghed1ew->leftout=gonghexns;
    yonghed1ew->rightout=NULL;
    yonghed1ew->stout=NULL;
    yonghed1ew->carsum=10;
    yonghed1ew->laneleftout=0;
	yonghed1ew->lanerightout=1;
	yonghed1ew->lanestout=1;
	yonghed1ew->special=1;
	yonghed1ew->direction=2;
	yonghed1ew->speed=50/3.6;
	yonghed1ew->length=300;
	yonghed1ew->cargo=0;
	yonghed1ew->lastcar1=-1;
	yonghed1ew->lastcar2=-1;
	yonghed1ew->lastcar0=-1;
	yonghed1ew->golane=-1;
    
    yonghed2ew->leftout=guangyanns;
    yonghed2ew->rightout=NULL;
    yonghed2ew->stout=yonghed1ew;
    yonghed2ew->carsum=10;
    yonghed2ew->laneleftout=0;
	yonghed2ew->lanerightout=1;
	yonghed2ew->lanestout=0;
	yonghed2ew->special=0;
	yonghed2ew->direction=2;
	yonghed2ew->speed=50/3.6;
	yonghed2ew->length=300;
	yonghed2ew->cargo=0;
	yonghed2ew->lastcar1=-1;
	yonghed2ew->lastcar0=-1;
	yonghed2ew->lastcar2=-1;
	yonghed2ew->golane=-1;

    gonghexns->leftout=pengjiang1we;
    gonghexns->rightout=NULL;
    gonghexns->stout=NULL;
    gonghexns->carsum=10;
    gonghexns->laneleftout=0;
	gonghexns->lanerightout=1;
	gonghexns->lanestout=0;
	gonghexns->special=0;
	gonghexns->direction=4;
	gonghexns->speed=50/3.6;
	gonghexns->length=300;
	gonghexns->cargo=0;
	gonghexns->lastcar0=-1;
	gonghexns->lastcar1=-1;
	gonghexns->lastcar2=-1;
	gonghexns->golane=-1;
    
    guangyanns->leftout=pengjiang2we;
    guangyanns->rightout=pengjiang1ew;
    guangyanns->stout=NULL;
    guangyanns->carsum=10;
    guangyanns->laneleftout=1;
	guangyanns->lanerightout=1;
	guangyanns->lanestout=0;
	guangyanns->special=0;
	guangyanns->direction=4;
	guangyanns->speed=50/3.6;
    guangyanns->length=400;
    guangyanns->cargo=0;
    guangyanns->lastcar0=-1;
    guangyanns->lastcar1=-1;
    guangyanns->lastcar2=-1;
    guangyanns->golane=-1;
                                                                                                          
    pengjiang1ew->leftout=NULL;
    pengjiang1ew->rightout=gonghexsn;
    pengjiang1ew->stout=NULL;
    pengjiang1ew->carsum=10;
    pengjiang1ew->laneleftout=1;
	pengjiang1ew->lanerightout=0;
	pengjiang1ew->lanestout=1;
	pengjiang1ew->special=0;
    pengjiang1ew->direction=2;
    pengjiang1ew->speed=50/3.6;
	pengjiang1ew->length=200;
	pengjiang1ew->cargo=0;
	pengjiang1ew->lastcar0=-1;
	pengjiang1ew->lastcar1=-1;
	pengjiang1ew->lastcar2=-1;
	pengjiang1ew->golane=-1;

    pengjiang2ew->leftout=NULL;
    pengjiang2ew->rightout=guangyansn;
    pengjiang2ew->stout=pengjiang1ew;
    pengjiang2ew->carsum=10;
    pengjiang2ew->laneleftout=1;
	pengjiang2ew->lanerightout=0;
	pengjiang2ew->lanestout=0;
	pengjiang2ew->special=0;
	pengjiang2ew->direction=2;
	pengjiang2ew->speed=50/3.6;
    pengjiang2ew->length=200;
    pengjiang2ew->cargo=0;
    pengjiang2ew->lastcar0=-1;
    pengjiang2ew->lastcar1=-1;
    pengjiang2ew->lastcar2=-1;
    pengjiang2ew->golane=-1;

    pingxinggns->leftout=NULL;
    pingxinggns->rightout=pengjiang2ew;
    pingxinggns->stout=NULL;
    pingxinggns->carsum=10;
    pingxinggns->laneleftout=1;
	pingxinggns->lanerightout=0;
	pingxinggns->lanestout=0;
	pingxinggns->special=0;
	pingxinggns->direction=4;
	pingxinggns->speed=50/3.6;
	pingxinggns->length=450;
	pingxinggns->cargo=0;
	pingxinggns->lastcar0=-1;
	pingxinggns->lastcar1=-1;
	pingxinggns->lastcar2=-1;
	pingxinggns->golane=-1;
	
	
	
	
	
	scanf("%d",&time1);
	carp=malloc(sizeof(car)*carall);
	
	t=0;
	s=yonghed1we->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=yonghed1we;
		
	}
		t=t+yonghed1we->carsum;
		s=s+yonghed2we->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=yonghed2we;
		
	}
		t=t+yonghed2we->carsum;
		s=s+gonghexns->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=gonghexns;
		
	}
		t=t+gonghexns->carsum;
		s=s+guangyanns->carsum;
	
	for(a=t;a<s;a++)
	{
		carp[a].location=guangyanns;
		
	}
		t=t+guangyanns->carsum;
		s=s+pengjiang1we->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pengjiang1we;
		
	}
		t=t+pengjiang1we->carsum;
		s=s+pengjiang2we->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pengjiang2we;
		
	}
		t=t+pengjiang2we->carsum;
		s=s+pingxinggns->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pingxinggns;
		
	}
		t=t+pingxinggns->carsum;
		s=s+yonghed1ew->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=yonghed1ew;
		
	}
		t=t+yonghed1ew->carsum;
		s=s+yonghed2ew->carsum;
	
	for(a=t;a<s;a++)
	{
		carp[a].location=yonghed2ew;
		
	}
		t=t+yonghed2ew->carsum;
		s=s+gonghexsn->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=gonghexsn;
		
	}
		t=t+gonghexsn->carsum;
		s=s+guangyansn->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=guangyansn;
		
	}
		t=t+guangyansn->carsum;
		s=s+pengjiang1ew->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pengjiang1ew;
		
	}
		t=t+pengjiang1ew->carsum;
		s=s+pengjiang2ew->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pengjiang2ew;
		
	}
		t=t+pengjiang2ew->carsum;
		s=s+pingxinggsn->carsum;
	for(a=t;a<s;a++)
	{
		carp[a].location=pingxinggsn;
	}

	
	
	origin();
	
	for(timeall=0;timeall<time1;timeall++)
	{
		for(carnum=0;carnum<carall;carnum++)
		{
			if(carp[carnum].out==0)
			{
				gogogo(carnum);
				m=carp[carnum].gone;
				if(m==maxgone(carp[carnum].location)&&carp[carnum].location->cargo==0)
				{
					light(carnum);
				}
			}
		}
		for(b=0;b<carall;b++)
		{
			if(carp[b].location!=NULL) 
			carp[b].location->cargo=0;
		}
	
	} 
	printf("%d\n",carall-cut);
}
