#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"
extern int timeall;
int timejudge()
{
	int i;
	if(timeall%60<=30)
	i=0;
	if(timeall%60>30)
	i=1;
	return i;
}
