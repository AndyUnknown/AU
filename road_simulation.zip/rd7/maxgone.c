#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"
double maxgone(roadwesn *m)
{
	double t;
	t=(m->length);
	return t;
}
