#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"
extern car *carp;
extern int carall;
extern int dir( roadwesn *m,int o);
extern int roadstatus(roadwesn *m);
extern int roadsta[3];
extern int timeall;
extern int cut;
extern roadwesn *yonghed1we;
extern int carnum;
extern int timejudge();
void light(int n)
{
	int a,b[3],c,d,r,i,o,t,count;
    
    i=roadstatus(carp[n].location);

    if(timejudge()==0)
    {
   		if(carp[n].direction==1&&carp[n].location->leftout==NULL)
	    {
    		
		    cut++;
		    carp[n].out=1;
		    if(carp[n].backcar!=-1)
		    {
		    	carp[carp[n].backcar].frontcar=-1;
		    	carp[n].backcar=-1;
			} 
			carp[n].location->cargo=1;
			if(carp[n].location->lastcar1==n)
	    	carp[n].location->lastcar1=-1; 
			carp[n].location=NULL; 
		    printf("at %d, car %d outed\n",timeall,n);
		    goto l1;
    	}
    	
    	if(carp[n].direction==2&&carp[n].location->rightout==NULL)
	    {
    		
    	
		    cut++;
		    carp[n].out=1;
		    if(carp[n].backcar!=-1)
		    {
		    	carp[carp[n].backcar].frontcar=-1;
		    	carp[n].backcar=-1;
			} 
			carp[n].location->cargo=1;
			if(carp[n].location->lastcar2==n)
	    	carp[n].location->lastcar2=-1; 
	    	carp[n].location=NULL; 
		    printf("at %d, car %d outed\n",timeall,n);
		    goto l1;
    	}
    	
     	if(carp[n].direction==2&&carp[n].location->rightout!=NULL)
    	{
	    	carp[n].location->rightout->carsum++;
	    	carp[n].location->carsum--;
	    	carp[n].gone=0;
	    	carp[n].location->cargo=1;
	    	if(carp[n].location->lastcar2==n)
	    	carp[n].location->lastcar2=-1; 
	    	carp[n].location=carp[n].location->rightout;
	    	
	    	
	    	printf("car %d turned %d at %d s.\n",n,carp[n].direction,timeall);
	    	carp[n].direction=-1;

	    	carp[n].lane=dir(carp[n].location,n);
	    	
	    	
	    	
	    	if(carp[n].lane==0)
	    	{
	    		t=carp[n].location->lastcar0;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar0==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar0;
	    		carp[n].location->lastcar0=n;
	    		
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==1)
	    	{
	    		t=carp[n].location->lastcar1;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar1==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar1;
	    		carp[n].location->lastcar1=n;
	    		
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==2)
	    	{
	    		t=carp[n].location->lastcar2;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar2==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar2;
	    		carp[n].location->lastcar2=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	   	
	    	carp[n].backcar=-1;
			goto l1;
			
	    }
	    
    	
    	
	    if(carp[n].direction==1&&carp[n].location->leftout!=NULL)
	    {
    		carp[n].location->leftout->carsum++;
	    	carp[n].location->carsum--;
	    	carp[n].gone=0;
	    	carp[n].location->cargo=1;
	    	if(carp[n].location->lastcar1==n)
	    	carp[n].location->lastcar1=-1; 
	    	
	    	carp[n].location=carp[n].location->leftout;
	    	//printf("car %d turned %d at %d s.\n",n,carp[n].direction,timeall);
	    	carp[n].direction=-1;

	    	carp[n].lane=dir(carp[n].location,n);
	    	
	    	
	    	
	    	if(carp[n].lane==0)
	    	{
	    		t=carp[n].location->lastcar0;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar0==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar0;
	    		carp[n].location->lastcar0=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==1)
	    	{
	    		t=carp[n].location->lastcar1;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar1==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar1;
	    		carp[n].location->lastcar1=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
   	
	    	if(carp[n].lane==2)
	    	{
	    		t=carp[n].location->lastcar2;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar2==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar2;
	    		carp[n].location->lastcar2=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	carp[n].backcar=-1;
			goto l1;
	    	
    	}
    	
		
    }
    
    
    
    
	if(timejudge()==1)
	{
		if(carp[n].direction==0&&carp[n].location->stout==NULL)
	    {
    		
    		
		    cut++;
		    carp[n].out=1;
		    if(carp[n].backcar!=-1)
		    {
		    	carp[carp[n].backcar].frontcar=-1;
		    	carp[n].backcar=-1;
			} 
			carp[n].location->cargo=1;
			if(carp[n].location->lastcar0==n)
	    	carp[n].location->lastcar0=-1; 
			carp[n].location=NULL; 
		    printf("at %d, car %d outed\n",timeall,n);
		    goto l1;
	    }
	    
	    if(carp[n].direction==2&&carp[n].location->rightout==NULL)
	    {
    		
    		
		    cut++;
		    carnum--;
		    carp[n].out=1;
		    if(carp[n].backcar!=-1)
		    {
		    	carp[carp[n].backcar].frontcar=-1;
		    	carp[n].backcar=-1;
			} 
		    carp[n].location->cargo=1;
		    if(carp[n].location->lastcar2==n)
	    	carp[n].location->lastcar2=-1; 
			carp[n].location=NULL; 
		    printf("at %d, car %d outed\n",timeall,n);
		    goto l1;
    	}
    	
    	if(carp[n].direction==2&&carp[n].location->rightout!=NULL)
    	{
	    	carp[n].location->rightout->carsum++;
	    	carp[n].location->carsum--;
	    	carp[n].gone=0;
	    	
	    	carp[n].location->cargo=1;
	    	if(carp[n].location->lastcar2==n)
	    	carp[n].location->lastcar2=-1; 
	    	
	    	carp[n].location=carp[n].location->rightout;
	    	//printf("car %d turned %d at %d s.\n",n,carp[n].direction,timeall);
	    	carp[n].direction=-1;
	    	
	    	carp[n].lane=dir(carp[n].location,n);
	    	
	    	
	    	
	    	if(carp[n].lane==0)
	    	{
	    		t=carp[n].location->lastcar0;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar0==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar0;
	    		carp[n].location->lastcar0=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==1)
	    	{
	    		t=carp[n].location->lastcar1;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar1==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar1;
	    		carp[n].location->lastcar1=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==2)
	    	{
	    		t=carp[n].location->lastcar2;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar2==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar2;
	    		carp[n].location->lastcar2=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	carp[n].backcar=-1;
			goto l1;
	    }
	    
	    
	    if(carp[n].direction==0&&carp[n].location->stout!=NULL)
	    {
    		carp[n].location->stout->carsum++;
    		
	    	carp[n].location->carsum--;
	    	carp[n].gone=0;
	    	carp[n].location->cargo=1;
	    	if(carp[n].location->lastcar0==n)
	    	carp[n].location->lastcar0=-1; 
	    	
	    	carp[n].location=carp[n].location->stout;
	    	printf("car %d turned %d at %d s.\n",n,carp[n].direction,timeall);
	    	carp[n].direction=-1;

	    	carp[n].lane=dir(carp[n].location,n);
	    	
	    	
	    	if(carp[n].lane==0)
	    	{
	    		t=carp[n].location->lastcar0;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar0==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar0;
	    		carp[n].location->lastcar0=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==1)
	    	{
	    		t=carp[n].location->lastcar1;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar1==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar1;
	    		carp[n].location->lastcar1=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	
	    	if(carp[n].lane==2)
	    	{
	    		t=carp[n].location->lastcar2;
	    		if(t!=-1)
	    		carp[t].backcar=n;
	    		
	    		if(carp[n].location->lastcar2==-1)
	    		carp[n].frontcar=-1;
	    		else
	    		carp[n].frontcar=carp[n].location->lastcar2;
	    		carp[n].location->lastcar2=n;
	    		if(carp[n].backcar!=-1)
	    		carp[carp[n].backcar].frontcar=-1;
				carp[n].backcar=-1;
	    	}
	    	carp[n].backcar=-1;
			goto l1;
l1:			a=a;
	    	
	    	
    	}	
	}
}
