#include<stdio.h>
#include"headers7.h"
extern car *carp;
extern int timeall;
extern int carall;
extern int roadstatus(roadwesn *m);
extern int dir( roadwesn *m,int o);
void origin()
{
	int a,c;
	for(a=0;a<carall;a++)
	{
		carp[a].speedcar=carp[a].location->speed;
		carp[a].backcar=carp[a].frontcar=-1;
		carp[a].lane=carp[a].direction=dir(carp[a].location,a);
		carp[a].gone=carp[a].status=carp[a].out=0;
	}
	for(a=0;a<carall;a++)
	{
		for(c=a+1;c<carall;c++)
		{
			if(carp[a].location==carp[c].location&&carp[a].lane==carp[c].lane&&carp[a].backcar==-1&&carp[c].frontcar==-1)
			{
				carp[a].backcar=c;
				carp[c].frontcar=a;
				break;
			}
		}
	}

}