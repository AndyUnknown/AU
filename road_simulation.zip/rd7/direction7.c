#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"
extern int roadstatus(roadwesn *m);
extern car *carp;
int dir( roadwesn *m,int o)
{
	int r,a,c,d,i,l;
		    d=rand();
      	    c=d%3;
         
         	if(c==0)
         	carp[o].direction=carp[o].lane=0;
         	if(c==1)
         	carp[o].direction=carp[o].lane=1;
         	if(c==2)
         	carp[o].direction=carp[o].lane=2;
  
	return(carp[o].direction);
}
