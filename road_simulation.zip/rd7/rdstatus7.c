#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include"headers7.h"
int roadstatus(roadwesn *m)
{
	int x=0,y=0,z=0,i;
    if(m->leftout==NULL)
    y=y+1;
    if(m->rightout==NULL)
    z=z+1;
    if(m->stout==NULL)
    x=x+1;
	if(x==0&&y==0&&z==0)
	i=0;
	if(x==0&&y==0&&z==1)
	i=1;
	if(x==0&&y==1&&z==0)
	i=2;
	if(x==1&&y==0&&z==0)
	i=3;
	if(x==0&&y==1&&z==1)
	i=4;
	if(x==1&&y==1&&z==0)
	i=5;
	if(x==1&&y==0&&z==1)
	i=6;
	if(x==1&&y==1&&z==1)
	i=7;
	return i;
}
