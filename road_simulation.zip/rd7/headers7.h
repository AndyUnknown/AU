typedef struct _roadwesn
{
	struct _roadwesn* leftout;
	struct _roadwesn* rightout;
	struct _roadwesn* stout;
	int carsum;
	int laneleftout;
	int lanerightout;
	int lanestout;
	int special;
	double length;
	double speed;
    int direction;
    int cargo;
    int ready;
    int golane;
    int lastcar0;
    int lastcar1;
    int lastcar2;
}roadwesn;

typedef struct 
{
	struct _roadwesn* location;
	double gone;
	int status;
	int direction;
	double speedcar;
	int frontcar;
	int backcar;
	int lane;
	int out;
}car;
