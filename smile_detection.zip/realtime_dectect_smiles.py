import argparse
import cv2,os,msvcrt
import joblib
import feature_get
from sklearn.svm import SVC

faceCascade = cv2.CascadeClassifier('xmls/haarcascade_frontalface_default.xml')
def detect_face(in_img):
    if in_img.ndim == 3:
        gray = cv2.cvtColor(in_img, cv2.COLOR_BGR2GRAY)
    elif in_img.ndim == 1:
        gray = in_img
    face_locations = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=8,
        minSize=(55, 55),
        flags=cv2.CASCADE_SCALE_IMAGE
    )
    return face_locations
    



def use_camera_to_detect(method='hog'):

    methods = {
        'hog': 'h',
        'lbp': 'l',
    }

    if(methods[method]=='l'):
        svc=joblib.load('svc_by_lbp.model')
    else:
        svc=joblib.load('svc_by_hog.model')


    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    face_feather_for_temp_train=[]
    labels_for_temp_train=[]
    fulfilled=[0,0]   
    color=(0,255,255)
    while True:            
        res, frame = cap.read()
        
        if not res:
            print('err reading camera.')
            break
            
        draw_img = frame.copy()
        face_locations = detect_face(frame)
        ch='0'
          
        for (x, y, w, h) in face_locations:
            cv2.rectangle(draw_img, (x, y), (x + w, y + h), color, 2)
            face = frame[y:y + h, x:x + w]

            face_feature=[]
            feather_array=[]
            if(methods[method]=='l'):
                feather_array=(feature_get.Lbp(face))
            else:
                feather_array=(feature_get.Hog(face))
           
            face_feature.append(feather_array)
            predict_result = svc.predict(face_feature)
            if  predict_result[0]:
                cv2.rectangle(draw_img, (x, y), (x + w, y+ h), (0, 0, 255), 3)
                cv2.putText(draw_img, 'Smiling', (x, y - 7), 3, 1.2, (0, 255, 0), 1, cv2.LINE_AA)

            cv2.waitKey(1)

            if msvcrt.kbhit():
                ch=msvcrt.getch()
            if ord(ch) == ord('n'):
                if not fulfilled[0]:
                    color=(255, 0, 255)
                else:
                    color=(0,255,255)
                face_feather_for_temp_train.append(feather_array)
                labels_for_temp_train.append(0)
                fulfilled[1]=1
                ch='0'
                print(fulfilled)

            if ord(ch) == ord('y'):
                if not fulfilled[1]:
                    color=(255, 255, 255)
                else:
                    color=(0,255,255)
                face_feather_for_temp_train.append(feather_array)
                labels_for_temp_train.append(1)
                fulfilled[0]=1
                ch='0'
                print(fulfilled)

            if(fulfilled==[1,1]):
                svc.fit(face_feather_for_temp_train,labels_for_temp_train)
                fulfilled=[0,0]

        cv2.imshow('Real-Time Face Detect', draw_img)
        cv2.waitKey(1)
        if msvcrt.kbhit() and ord(msvcrt.getch()) == ord('q'):
            break
        
    cap.release()
    cv2.destroyAllWindows()
        


use_camera_to_detect('lbp')