import numpy as np
from skimage.feature import local_binary_pattern
from skimage.feature import hog
import cv2
#function: get lbp feature
def Lbp(image_name): 
    '''
    This function is provided by Mao&Yang&Zhao
    input image_name: one color face image file name , str .Or an image itself
    output hist:  hist feature vecter, np.array
    '''

    image=[]
    if type(image_name)==str:
        image = cv2.imread(image_name)
    if type(image_name)==np.ndarray:
        image=image_name
        
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    block=5
    wideth=image.shape[1]
    heigh=image.shape[0]
    column = wideth // block
    row=heigh//block
    hist=np.array([])
    for i in range(block*block):
        lbp1 = local_binary_pattern(image[row*(i//block):row*((i//block)+1),column*(i % block):column*((i % block)+1)], 8, 1,  'nri_uniform')
        hist1, _ = np.histogram(lbp1,bins=256, range=(0, 256),density=True)
        hist=np.concatenate((hist,hist1))
    return hist

def Hog(image_name): 
    '''
    This function is not provided by Mao&Yang&Zhao
    input image_name: one color face image file name , str .Or an image itself
    output hog1: feature vecter, np.array
    '''
    image=[]
    if type(image_name)==str:
        image = cv2.imread(image_name)
    if type(image_name)==np.ndarray:
        image = image_name


    block=6
    wideth=image.shape[1]
    heigh=image.shape[0]
    column = wideth // block
    row=heigh//block

    hog1 = hog(image,orientations=12, pixels_per_cell=(row, column),cells_per_block=(block//3, block//3),block_norm='L2',transform_sqrt=True)
    return hog1

