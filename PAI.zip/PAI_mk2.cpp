// PAI_mk2.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "stdafx.h"
#include "vector"
#include "iostream"
#include "string"
using namespace std;

const int ACC1=5,ACC2=200;
int acc=ACC1+ACC2;

struct ldouble:vector<int>
{
	int sign;
	ldouble()
	{
		assign(ACC1+ACC2,0);
		sign=1;
	}
	void set_val(string s1,string s2)
	{
		int i;
		for(i=0;i<s1.size();++i)
			(*this)[ACC1-s1.size()+i]=s1[i]-'0';
		for(i=0;i<s2.size();++i)
			(*this)[ACC1+i]=s2[i]-'0';
	}

	void check()
	{
		int i;
		
		int zeronum=0;
		for(i=0;i<ACC1;i++)
			if((*this)[i]!=0)
				break;

		zeronum=i;
label:	for(i=acc-1;i>=0;--i)
		{
			if(i==0&&((*this)[i]>=10||(*this)[i]<=-10))
			{
				cout<<"BOUNDARY TOO SMALL";
				cin.get();
			}
				
			if((*this)[i]>10)
			{
				(*this)[i-1]+=(*this)[i]/10;
				(*this)[i]%=10;
			}
			if ((*this)[i]<0)
			{
				if(i==zeronum)
				{
					(*this).sign*=-1;
					for(int j=0;j<acc;j++)
						(*this)[j]=-(*this)[j];
					goto label;
				}
					
				int borrow=(-(*this)[i]-1)/10+1;
				(*this)[i-1]-=borrow;
				(*this)[i]+=borrow*10;
			}
		}
	}
};



ostream &operator<<(ostream &os,ldouble l1)
{
	int i,counter=0;
	if(l1.sign==-1)
		cout<<"-";
	for(i=0;i<ACC1;++i)
	{
		if(l1[i]!=0||counter==1)
			os<<l1[i];
		if(l1[i]!=0)
			counter=1;
	}
	if(counter==0)
		os<<"0";
	os<<".";
	for(i=ACC1;i<acc;++i)
		os<<l1[i];
	return os;
}

bool operator ==(ldouble l1,ldouble l2)
{	
	for(int i=0;i<acc;++i)
	{
		if(l1[i]!=l2[i])
			return 0;
	}
	return 1;
}

bool operator !=(ldouble l1,ldouble l2)
{	
	return !(l1==l2);
}

bool operator >(ldouble l1,ldouble l2)
{
	if(l1.sign==1&&l2.sign==-1)
		return 1;
	if(l1.sign==-1&&l2.sign==1)
		return 0;
	for(int i=0;i<acc;++i)
	{
		if(l1[i]>l2[i])
			if(l1.sign==l2.sign&&l1.sign==1)
				return 1;
			else
				return 0;
		if(l1[i]<l2[i])
			if(l1.sign==l2.sign&&l1.sign==1)
				return 0;
			else
				return 1;
	}
	return 0;
}

bool operator >=(ldouble l1,ldouble l2)
{
	return (l1>l2||l1==l2);
}

bool operator <=(ldouble l1,ldouble l2)
{
	return !(l1>l2);
}

bool operator <(ldouble l1,ldouble l2)
{
	return !(l1>=l2);
}



ldouble operator-(ldouble l1,ldouble l2)
{
	ldouble lmid,l;
	
	if(l1.sign==-1)
	{
		for(int i=0;i<acc;++i)
			l[i]=l1[i]+l2[i];
		l.check();
		l.sign*=-1;
		return l;
	}

	if(l2.sign==-1)
	{
		for(int i=0;i<acc;++i)
			l[i]=l1[i]+l2[i];
		l.check();
		return l;
	}

	if(l2>l1)
	{
		lmid=l2;
		l2=l1;
		l1=lmid;
		l.sign*=-1;
	}

	for(int i=0;i<acc;++i)
		l[i]=l1[i]-l2[i];
	l.check();
	return l;
}


ldouble operator+(ldouble l1,ldouble l2)
{
	ldouble l;
	if(l1.sign==-1)
	{
		l1.sign*=-1;
		return l2-l1;
	}
	if(l2.sign==-1)
	{
		l2.sign*=-1;
		return l1-l2;
	}

	for(int i=0;i<acc;++i)
		l[i]=l1[i]+l2[i];
	l.check();
	return l;
}


ldouble operator*(ldouble l1,ldouble l2)
{
	ldouble l0,l;
	l0.assign(2*acc-1,0);
	for(int i=acc-1;i>=0;--i)
	{
		for(int j=acc-1;j>=0;--j)
		l0[i+j]+=l1[i]*l2[j];
	}

	for(int i=0;i<ACC1-1;++i)
	{
		if(l0[i]!=0)
		{
			cout<<"TOO SMALL";
			cin.get();
		}
	}

	for(int i=0;i<acc;++i)
		l[i]=l0[i+ACC1-1];
	if(l0[acc+ACC1-1]>=5)
		l[acc-1]+=1;

	l.check();
	l.sign=l1.sign*l2.sign;
	return l;
}

ldouble operator/(ldouble l1,ldouble l2)
{
	int z1,z2,counter=1;
	ldouble l0,lmid,l;

	if(l1.sign==-1)
		counter*=-1;
	if(l2.sign==-1)
		counter*=-1;
	l1.sign=l2.sign=1;
	for(int i=0;i<acc;++i)
	{
		if(l1[i]!=0)
			break;
		z1=i;		
	}
	for(int i=0;i<acc;++i)
	{
		if(l2[i]!=0)
			break;
		z2=i;		
	}
		

	for(int i=z2-z1;i>-ACC2-1;--i)
	{
		l0[ACC1-1-i]=1;
		l0[ACC1-2-i]=0;
		lmid=l0*l2;
		while(l1>=lmid)
		{
			l1=l1-lmid;
			l=l+l0;
		}
	}
	l.check();
	l.sign=counter;
	return l;

}

ldouble sqr(ldouble l1)
{
	return l1*l1;
}


ldouble sqt(ldouble l1,ldouble l2)
{
	ldouble l,lhalf,ltemp,lmin;
	if(l1.sign==-1)
		cout<<"YOU CANT SQT THIS";
	l2.sign=1;
	lhalf.set_val("0","5");
	lmin[acc*0.95]=1;
	while(1)
	{
		ltemp=lhalf*((l1/l2)+l2);
		if((ltemp-l2<lmin&&ltemp>=l2)||(l2-ltemp<lmin&&l2>=ltemp))
			break;
		l2=ltemp;
		l.check();
	}
	l=l2;
	
	return l;
}


ldouble PAI()
{
	ldouble a,b,t,p,one,two,a1,b1,t1,p1,PAI;
	one.set_val("1","0");
	two.set_val("2","0");
	a=one;
	b=one/sqt(two,two);
	t=sqr(one/two);
	p=one;

	for(int i=0;i<10;++i)
	{
		a1=(a+b)/two;
		b1=sqt(a*b,two);
		t1=t-p*sqr(a-a1);
		p1=two*p;

		a=a1;
		b=b1;
		t=t1;
		p=p1;
	}

	PAI=sqr(a+b)/(sqr(two)*t);
	return PAI;

}



int _tmain(int argc, _TCHAR* argv[])
{
	ldouble l1,l2;
	l1.set_val("2","0");
	l2.set_val("1","4");
	cout<<PAI();
	cin.get();
	return 0;
}